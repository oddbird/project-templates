CHANGES
=======

0.1.2 (2011.06.27)
------------------

* Added ``AjaxMessagesMiddleware`` and ``handleAjax`` plugin option.


0.1.1 (2011.06.27)
------------------

* Updated HTML template (removed ``<aside>`` and moved ``#messages`` to
  ``<ul>``).


0.1.0 (2011.06.25)
------------------

* Initial release.
